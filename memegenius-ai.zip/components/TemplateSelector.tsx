import React from 'react';

interface TemplateSelectorProps {
  onSelect: (url: string) => void;
}

const TEMPLATES = [
  "https://picsum.photos/id/1025/600/600", // Dog
  "https://picsum.photos/id/237/600/600", // Puppy
  "https://picsum.photos/id/1003/600/600", // Deer
  "https://picsum.photos/id/1074/600/600", // Lion
  "https://picsum.photos/id/1062/600/600", // Dog wrapped
  "https://picsum.photos/id/433/600/600", // Bear
  "https://picsum.photos/id/659/600/600", // Husky
  "https://picsum.photos/id/169/600/600", // Road
];

const TemplateSelector: React.FC<TemplateSelectorProps> = ({ onSelect }) => {
  return (
    <div className="grid grid-cols-4 gap-2 mt-4">
      {TEMPLATES.map((url, idx) => (
        <button
          key={idx}
          onClick={() => onSelect(url)}
          className="relative aspect-square overflow-hidden rounded-lg hover:ring-2 hover:ring-primary transition-all group"
        >
          <img 
            src={url} 
            alt="Meme Template" 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
        </button>
      ))}
    </div>
  );
};

export default TemplateSelector;